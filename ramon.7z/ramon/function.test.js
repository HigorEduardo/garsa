const {ordenarArray} = require("./menor")
const {calcularArea} = require("./menor")

test('ordena a lista', ()=>{
    const entrada = [-5,2,-3,4,1]
    const saida = [-5,-3,1,2,4]
    expect(ordenarArray(entrada)).toEqual(saida)
})


test('calcula área', ()=>{
    const entrada = [5,10]
    const saida = [50]
    expect(calcularArea(entrada)).toEqual(saida)
})