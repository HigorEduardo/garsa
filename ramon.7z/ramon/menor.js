/*function ordenarArray(array) {
   
    array.sort(function(a, b) {
        return a - b; 
    });

    return array; 
}
let arrayOriginal = [5, 1, 8, 3, 2];

let arrayOrdenado = ordenarArray(arrayOriginal);
console.log("Array ordenado:", arrayOrdenado);

module.exports={ordenarArray}*/

function calcularArea(forma) {

    switch (forma.tipo) {
        case 'retangulo':
            return forma.largura * forma.altura;
        case 'circulo':
            return Math.PI * Math.pow(forma.raio, 2);
        default:
            return 0; 
    }
}

const retangulo = {
    tipo: 'retangulo',
    largura: 5,
    altura: 10
};

const circulo = {
    tipo: 'circulo',
    raio: 7
};

console.log(`${calcularArea(retangulo)}`);
console.log(`${calcularArea(circulo)}`);

module.exports={calcularArea}